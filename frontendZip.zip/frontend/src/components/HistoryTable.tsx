import React, { useEffect, useState, useCallback } from 'react';
import { getHistory } from '../api/client';
import type { AnalyzeResult } from '../types/api';
import { VerdictBadge } from './VerdictBadge';
import { fmtTime, fmtLatency, fmtConfidence } from '../utils/helpers';

const PAGE_SIZE = 10;

export function HistoryTable() {
  const [items, setItems] = useState<AnalyzeResult[]>([]);
  const [total, setTotal] = useState(0);
  const [offset, setOffset] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (off: number) => {
    setLoading(true);
    setError(null);
    try {
      const data = await getHistory(PAGE_SIZE, off);
      setItems(data.items);
      setTotal(data.total);
      setOffset(off);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load history');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(0); }, [load]);

  const totalPages = Math.ceil(total / PAGE_SIZE);
  const currentPage = Math.floor(offset / PAGE_SIZE) + 1;

  return (
    <div className="history-container">
      <div className="history-header">
        <h2 className="history-title">Recent Analyses</h2>
        <button
          className="btn-refresh"
          onClick={() => load(offset)}
          disabled={loading}
          aria-label="Refresh history"
        >
          {loading ? '⟳' : '↻'} Refresh
        </button>
      </div>

      {error && <div className="error-banner">⚠ {error}</div>}

      {!error && items.length === 0 && !loading && (
        <div className="history-empty">No analyses yet. Upload an audio file to get started.</div>
      )}

      {items.length > 0 && (
        <>
          <div className="table-wrapper" role="region" aria-label="Analysis history">
            <table className="history-table">
              <thead>
                <tr>
                  <th>Time</th>
                  <th>Verdict</th>
                  <th>Risk</th>
                  <th>Confidence</th>
                  <th>Latency</th>
                  <th>Caller ID</th>
                  <th>Scan ID</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item) => (
                  <tr key={item.scan_id} className={`row-${item.verdict}`}>
                    <td className="td-time">{fmtTime(item.timestamp)}</td>
                    <td><VerdictBadge verdict={item.verdict} /></td>
                    <td>
                      <span className={`risk-cell risk-cell-${item.verdict}`}>
                        {item.risk_score.toFixed(1)}
                      </span>
                    </td>
                    <td>{fmtConfidence(item.confidence)}</td>
                    <td className="mono">{fmtLatency(item.latency_ms)}</td>
                    <td className="td-caller">{item.caller_id ?? <span className="muted">—</span>}</td>
                    <td>
                      <code className="scan-id-mini">{item.scan_id.slice(0, 8)}…</code>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="pagination">
            <span className="pagination-info">
              Showing {offset + 1}–{Math.min(offset + PAGE_SIZE, total)} of {total}
            </span>
            <div className="pagination-buttons">
              <button
                className="btn-page"
                onClick={() => load(Math.max(0, offset - PAGE_SIZE))}
                disabled={offset === 0 || loading}
                aria-label="Previous page"
              >
                ← Prev
              </button>
              <span className="page-indicator">
                {currentPage} / {totalPages}
              </span>
              <button
                className="btn-page"
                onClick={() => load(offset + PAGE_SIZE)}
                disabled={offset + PAGE_SIZE >= total || loading}
                aria-label="Next page"
              >
                Next →
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
