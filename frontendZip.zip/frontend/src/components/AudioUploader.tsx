import React, { useCallback, useRef, useState } from 'react';
import { fmtBytes } from '../utils/helpers';

interface Props {
  onFileSelected: (file: File, durationSec: number | undefined) => void;
  onClear?: () => void;
  disabled?: boolean;
}

const ACCEPTED = '.wav,.mp3,.flac,.ogg,.m4a,.webm';
const ACCEPTED_MIME = [
  'audio/wav', 'audio/wave', 'audio/x-wav',
  'audio/mpeg', 'audio/mp3',
  'audio/flac', 'audio/x-flac',
  'audio/ogg',
  'audio/mp4', 'audio/m4a', 'audio/x-m4a',
  'audio/webm',
];

function extractAudioDuration(file: File): Promise<number | undefined> {
  return new Promise((resolve) => {
    try {
      const url = URL.createObjectURL(file);
      const audio = new Audio();
      audio.src = url;
      audio.onloadedmetadata = () => {
        URL.revokeObjectURL(url);
        resolve(isFinite(audio.duration) ? audio.duration : undefined);
      };
      audio.onerror = () => { URL.revokeObjectURL(url); resolve(undefined); };
      setTimeout(() => { URL.revokeObjectURL(url); resolve(undefined); }, 4000);
    } catch {
      resolve(undefined);
    }
  });
}

export function AudioUploader({ onFileSelected, onClear, disabled }: Props) {
  const [dragging, setDragging] = useState(false);
  const [selected, setSelected] = useState<{ file: File; duration?: number } | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback(async (file: File) => {
    const isAudio = ACCEPTED_MIME.includes(file.type) || file.name.match(/\.(wav|mp3|flac|ogg|m4a|webm)$/i);
    if (!isAudio) {
      alert(`Unsupported file type: "${file.type || 'unknown'}". Please upload WAV, MP3, FLAC, OGG, M4A, or WebM.`);
      return;
    }
    const duration = await extractAudioDuration(file);
    setSelected({ file, duration });
    onFileSelected(file, duration);
  }, [onFileSelected]);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const onInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
    // reset so the same file can be re-selected
    e.target.value = '';
  }, [handleFile]);

  const clear = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    setSelected(null);
    onClear?.();
  }, [onClear]);

  return (
    <div
      className={`audio-uploader ${dragging ? 'dragging' : ''} ${selected ? 'has-file' : ''} ${disabled ? 'uploader-disabled' : ''}`}
      onDragEnter={() => !disabled && setDragging(true)}
      onDragLeave={() => setDragging(false)}
      onDragOver={(e) => { e.preventDefault(); }}
      onDrop={disabled ? undefined : onDrop}
      onClick={() => !disabled && !selected && inputRef.current?.click()}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && !disabled && !selected && inputRef.current?.click()}
      aria-label="Audio file upload area"
    >
      <input
        ref={inputRef}
        type="file"
        accept={ACCEPTED}
        className="sr-only"
        onChange={onInputChange}
        disabled={disabled}
        aria-label="Select audio file"
      />

      {!selected ? (
        <div className="uploader-empty">
          <div className="uploader-icon">🎙</div>
          <p className="uploader-main">Drop audio file here or click to browse</p>
          <p className="uploader-sub">Supports WAV · MP3 · FLAC · OGG · M4A</p>
          <p className="uploader-sub uploader-hint">Best results: WAV PCM 16 kHz mono</p>
        </div>
      ) : (
        <div className="uploader-selected">
          <div className="uploader-file-icon">🎵</div>
          <div className="uploader-file-info">
            <span className="uploader-filename" title={selected.file.name}>
              {selected.file.name}
            </span>
            <span className="uploader-meta">
              {fmtBytes(selected.file.size)}
              {selected.duration != null && ` · ${selected.duration.toFixed(1)} s`}
            </span>
          </div>
          {!disabled && (
            <button
              className="uploader-clear"
              onClick={clear}
              aria-label="Remove selected file"
              title="Remove"
            >
              ✕
            </button>
          )}
        </div>
      )}
    </div>
  );
}
