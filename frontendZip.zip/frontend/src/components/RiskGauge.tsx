import React from 'react';

interface Props {
  score: number; // 0–100
  animate?: boolean;
}

/**
 * SVG arc gauge that shows risk_score (0–100).
 * Colour bands:
 *   0–35   = cyan/green (low risk)
 *   36–64  = amber (uncertain)
 *   65–100 = crimson (high risk / cloned)
 */
export function RiskGauge({ score, animate = true }: Props) {
  const clampedScore = Math.max(0, Math.min(100, score));

  const R = 80;
  const cx = 110;
  const cy = 110;
  const startAngle = -220;
  const totalArc = 260; // degrees

  function polarToXY(angleDeg: number, r: number) {
    const rad = ((angleDeg - 90) * Math.PI) / 180;
    return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
  }

  function describeArc(startDeg: number, endDeg: number, r: number) {
    const s = polarToXY(startDeg, r);
    const e = polarToXY(endDeg, r);
    const large = endDeg - startDeg > 180 ? 1 : 0;
    return `M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 1 ${e.x} ${e.y}`;
  }

  const endAngle = startAngle + (clampedScore / 100) * totalArc;

  let scoreColor: string;
  if (clampedScore <= 35) scoreColor = '#00d4ff';
  else if (clampedScore <= 64) scoreColor = '#ffb347';
  else scoreColor = '#ff3d5a';

  let band: string;
  if (clampedScore <= 35) band = 'LOW RISK';
  else if (clampedScore <= 64) band = 'UNCERTAIN';
  else band = 'HIGH RISK';

  return (
    <div className="risk-gauge-wrapper">
      <svg
        viewBox="0 0 220 170"
        className={`risk-gauge-svg ${animate ? 'gauge-animate' : ''}`}
        aria-label={`Risk score: ${clampedScore} out of 100`}
        role="img"
      >
        {/* Track arc */}
        <path
          d={describeArc(startAngle, startAngle + totalArc, R)}
          fill="none"
          stroke="rgba(255,255,255,0.07)"
          strokeWidth="14"
          strokeLinecap="round"
        />

        {/* Band markers */}
        {[35, 65].map((pct) => {
          const ang = startAngle + (pct / 100) * totalArc;
          const inner = polarToXY(ang, R - 9);
          const outer = polarToXY(ang, R + 9);
          return (
            <line
              key={pct}
              x1={inner.x}
              y1={inner.y}
              x2={outer.x}
              y2={outer.y}
              stroke="rgba(255,255,255,0.18)"
              strokeWidth="1.5"
            />
          );
        })}

        {/* Active arc */}
        {clampedScore > 0 && (
          <path
            d={describeArc(startAngle, endAngle, R)}
            fill="none"
            stroke={scoreColor}
            strokeWidth="14"
            strokeLinecap="round"
            style={{
              filter: `drop-shadow(0 0 8px ${scoreColor}88)`,
            }}
          />
        )}

        {/* Center score */}
        <text
          x={cx}
          y={cy + 4}
          textAnchor="middle"
          dominantBaseline="middle"
          fill={scoreColor}
          fontSize="34"
          fontWeight="800"
          fontFamily="Inter, sans-serif"
          style={{ filter: `drop-shadow(0 0 6px ${scoreColor}66)` }}
        >
          {clampedScore.toFixed(0)}
        </text>
        <text
          x={cx}
          y={cy + 28}
          textAnchor="middle"
          fill="rgba(255,255,255,0.45)"
          fontSize="10"
          fontFamily="Inter, sans-serif"
          fontWeight="500"
          letterSpacing="2"
        >
          RISK SCORE
        </text>

        {/* Min/Max labels */}
        <text x="28" y="152" fill="rgba(255,255,255,0.3)" fontSize="9" fontFamily="Inter, sans-serif">0</text>
        <text x="185" y="152" fill="rgba(255,255,255,0.3)" fontSize="9" fontFamily="Inter, sans-serif">100</text>
      </svg>

      <div className="risk-band-label" style={{ color: scoreColor }}>
        {band}
      </div>
    </div>
  );
}
