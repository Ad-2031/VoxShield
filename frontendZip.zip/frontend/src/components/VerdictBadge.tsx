import React from 'react';
import type { Verdict } from '../types/api';
import { verdictLabel } from '../utils/helpers';

interface Props {
  verdict: Verdict;
  pulse?: boolean;
}

export function VerdictBadge({ verdict, pulse = false }: Props) {
  return (
    <span
      className={`verdict-badge verdict-${verdict} ${pulse && verdict === 'cloned' ? 'verdict-pulse' : ''}`}
      role="status"
      aria-label={`Verdict: ${verdictLabel(verdict)}`}
    >
      <span className="verdict-dot" />
      {verdict === 'real' && '✓ '}
      {verdict === 'cloned' && '⚠ '}
      {verdict === 'uncertain' && '◉ '}
      {verdictLabel(verdict)}
    </span>
  );
}
