import React from 'react';
import { API_BASE } from '../api/client';

interface Props {
  online: boolean | null;
}

export function Navbar({ online }: Props) {
  return (
    <header className="navbar" role="banner">
      <div className="navbar-inner">
        <div className="navbar-brand">
          <span className="navbar-logo" aria-hidden="true">🛡</span>
          <div className="navbar-title-group">
            <span className="navbar-title">VoxShield</span>
            <span className="navbar-tagline">AI-Powered Voice Integrity Verification</span>
          </div>
        </div>

        <div className="navbar-right">
          <div className={`backend-status ${online === null ? 'status-checking' : online ? 'status-online' : 'status-offline'}`}>
            <span className="status-dot" />
            <span className="status-text">
              {online === null ? 'Connecting…' : online ? `Backend online` : 'Backend offline'}
            </span>
            {online === false && (
              <span className="status-url" title={`Expected: ${API_BASE}`}>
                {API_BASE}
              </span>
            )}
          </div>

          <div className="navbar-badge">SIH 2026 · PS 26104</div>
        </div>
      </div>
    </header>
  );
}
