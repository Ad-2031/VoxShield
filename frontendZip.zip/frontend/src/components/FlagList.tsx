import React from 'react';
import { fmtFlag } from '../utils/helpers';

interface Props {
  flags: string[];
}

const FLAG_ICONS: Record<string, string> = {
  inconsistent_across_segments: '📊',
  clip_shorter_than_window_padded: '⏱',
  high_fake_probability_score: '🚨',
  borderline_score_low_margin: '⚡',
};

export function FlagList({ flags }: Props) {
  if (flags.length === 0) {
    return (
      <div className="flag-empty">
        <span className="flag-empty-icon">✓</span>
        No anomaly flags returned by the model.
      </div>
    );
  }

  return (
    <ul className="flag-list" aria-label="Explanation flags returned by the model">
      {flags.map((flag) => (
        <li key={flag} className="flag-item">
          <span className="flag-icon">{FLAG_ICONS[flag] ?? '▪'}</span>
          <span className="flag-text">{fmtFlag(flag)}</span>
          <code className="flag-raw">{flag}</code>
        </li>
      ))}
    </ul>
  );
}
