import React, { useState } from 'react';
import type { AnalyzeResult } from '../types/api';
import { submitFeedback, ApiError } from '../api/client';
import { RiskGauge } from './RiskGauge';
import { VerdictBadge } from './VerdictBadge';
import { FlagList } from './FlagList';
import {
  fmtTime,
  fmtLatency,
  fmtConfidence,
  fmtDuration,
  riskRecommendation,
  riskBand,
} from '../utils/helpers';

interface Props {
  result: AnalyzeResult;
}

type FeedbackState = 'idle' | 'submitting' | 'done' | 'error';

// ── small score bar component ───────────────────────────────────────────────
function ScoreBar({ score, label, available }: { score: number | null; label: string; available?: boolean | null }) {
  if (score == null) {
    return (
      <div className="score-bar-row">
        <span className="score-bar-label">{label}</span>
        <span className="score-bar-na">{available === false ? 'Unavailable' : '—'}</span>
      </div>
    );
  }
  const pct = Math.min(100, Math.max(0, score));
  const colour =
    pct < 30 ? 'var(--c-green)' : pct < 60 ? 'var(--c-yellow)' : 'var(--c-red)';
  return (
    <div className="score-bar-row">
      <span className="score-bar-label">{label}</span>
      <div className="score-bar-track">
        <div
          className="score-bar-fill"
          style={{ width: `${pct}%`, background: colour }}
        />
      </div>
      <span className="score-bar-value" style={{ color: colour }}>
        {pct.toFixed(0)}
      </span>
    </div>
  );
}

// ── speaker similarity indicator ───────────────────────────────────────────
function SpeakerBadge({ result }: { result: AnalyzeResult }) {
  if (!result.speaker_enrolled) {
    return (
      <span className="speaker-badge speaker-no-enroll">
        No voiceprint enrolled
      </span>
    );
  }
  if (result.speaker_similarity == null) {
    return <span className="speaker-badge speaker-unknown">Verification error</span>;
  }
  const verified = result.speaker_verified;
  return (
    <span className={`speaker-badge ${verified ? 'speaker-verified' : 'speaker-mismatch'}`}>
      {verified ? '✅ Speaker verified' : '❌ Speaker mismatch'} — {result.speaker_similarity.toFixed(0)}% similarity
    </span>
  );
}

// ── decision chip ──────────────────────────────────────────────────────────
function DecisionChip({ decision }: { decision: string | null }) {
  if (!decision) return null;
  const map: Record<string, { label: string; cls: string }> = {
    ALLOW: { label: '✓ ALLOW', cls: 'chip-allow' },
    REVIEW: { label: '◉ REVIEW', cls: 'chip-review' },
    BLOCK: { label: '✗ BLOCK', cls: 'chip-block' },
  };
  const { label, cls } = map[decision] ?? { label: decision, cls: '' };
  return <span className={`decision-chip ${cls}`}>{label}</span>;
}

// ── main component ─────────────────────────────────────────────────────────
export function ResultCard({ result }: Props) {
  const [feedbackState, setFeedbackState] = useState<FeedbackState>('idle');
  const [feedbackError, setFeedbackError] = useState<string | null>(null);
  const [notes, setNotes] = useState('');
  const [showFeedback, setShowFeedback] = useState(false);
  const [showDspBreakdown, setShowDspBreakdown] = useState(false);

  const band = riskBand(result.risk_score);

  async function handleFeedback(wasCorrect: boolean) {
    setFeedbackState('submitting');
    setFeedbackError(null);
    try {
      await submitFeedback({
        scan_id: result.scan_id,
        was_correct: wasCorrect,
        notes: notes.trim() || undefined,
      });
      setFeedbackState('done');
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : 'Feedback submission failed';
      setFeedbackError(msg);
      setFeedbackState('error');
    }
  }

  const recommendation = riskRecommendation(result.verdict);

  return (
    <div className={`result-card result-${result.verdict}`}>
      {/* Header */}
      <div className="result-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <h2 className="result-title">Detection Result</h2>
          <DecisionChip decision={result.decision} />
        </div>
        <VerdictBadge verdict={result.verdict} pulse />
      </div>

      {/* Disclaimer */}
      <div className="result-disclaimer">
        <span>⚠</span> This is an AI model output — not absolute proof of identity.
      </div>

      {/* Main layout: gauge + details */}
      <div className="result-body">
        {/* Gauge */}
        <div className="result-gauge-col">
          <RiskGauge score={result.risk_score} animate />
          <div className={`result-confidence band-${band}`}>
            Confidence: <strong>{fmtConfidence(result.confidence)}</strong>
          </div>
          {result.risk_level && (
            <div className={`risk-level-chip rl-${result.risk_level.toLowerCase()}`}>
              {result.risk_level} RISK
            </div>
          )}
        </div>

        {/* Details */}
        <div className="result-detail-col">
          <div className="result-grid">
            <MetaRow label="Scan ID">
              <code className="mono">{result.scan_id.slice(0, 18)}…</code>
            </MetaRow>
            <MetaRow label="Timestamp">{fmtTime(result.timestamp)}</MetaRow>
            <MetaRow label="Inference Latency">{fmtLatency(result.latency_ms)}</MetaRow>
            {result.audio_duration_sec != null && (
              <MetaRow label="Audio Duration">{fmtDuration(result.audio_duration_sec)}</MetaRow>
            )}
            {result.caller_id && (
              <MetaRow label="Caller ID"><code className="mono">{result.caller_id}</code></MetaRow>
            )}
          </div>

          {/* Recommendation box */}
          <div className={`recommendation-box band-${band}`}>
            <span className="recommendation-icon">
              {result.verdict === 'cloned' ? '🚨'
                : result.verdict === 'replayed' ? '📡'
                : result.verdict === 'uncertain' ? '⚡'
                : '✅'}
            </span>
            <span>{recommendation}</span>
          </div>
        </div>
      </div>

      {/* ── Detection Arm Scores ── */}
      <div className="result-section">
        <h3 className="section-title">
          Detection Arm Scores
          <span className="section-subtitle">Per-model breakdown</span>
        </h3>
        <div className="arm-scores-grid">
          {/* Arm 1: Synthetic */}
          <div className="arm-card">
            <div className="arm-header">
              <span className="arm-icon">🤖</span>
              <span className="arm-name">Synthetic / AI-Clone Detection</span>
            </div>
            <ScoreBar score={result.synthetic_score} label="Combined" />
            <ScoreBar score={result.xlsr_fake_prob} label="XLSR-AASIST" />
            <ScoreBar
              score={result.aasist3_fake_prob}
              label="AASIST3"
              available={result.aasist3_available}
            />
          </div>

          {/* Arm 2: DSP / Replay */}
          <div className="arm-card">
            <div className="arm-header">
              <span className="arm-icon">📡</span>
              <span className="arm-name">Replay &amp; DSP Spoof Detection</span>
            </div>
            <ScoreBar score={result.replay_score} label="Replay Attack" />
            <ScoreBar score={result.dsp_spoof_score} label="DSP Spoof (MFDSD)" available={result.dsp_available} />
            {result.rawnet2_available === false && (
              <p className="arm-note">RawNet2 unavailable — add weights/rawnet2_antispoofing.pth</p>
            )}
            {result.dsp_classification && (
              <p className="arm-note">
                DSP classified as:{' '}
                <strong style={{ color: result.dsp_classification === 'AI_GENERATED' ? 'var(--c-red)' : 'var(--c-green)' }}>
                  {result.dsp_classification}
                </strong>
              </p>
            )}
            {result.dsp_feature_scores && (
              <button
                className="arm-expand-btn"
                onClick={() => setShowDspBreakdown((v) => !v)}
              >
                {showDspBreakdown ? '▲' : '▼'} Feature breakdown
              </button>
            )}
            {showDspBreakdown && result.dsp_feature_scores && (
              <div className="dsp-feature-breakdown">
                {Object.entries(result.dsp_feature_scores).map(([k, v]) => (
                  <ScoreBar key={k} score={v * 100} label={k.replace(/_/g, ' ')} />
                ))}
              </div>
            )}
          </div>

          {/* Arm 3: Speaker verification */}
          <div className="arm-card">
            <div className="arm-header">
              <span className="arm-icon">🎤</span>
              <span className="arm-name">Speaker Verification (ECAPA)</span>
            </div>
            <SpeakerBadge result={result} />
            {result.speaker_similarity != null && (
              <ScoreBar
                score={100 - result.speaker_similarity}
                label="Identity Risk"
              />
            )}
          </div>
        </div>
      </div>

      {/* Explanation flags */}
      <div className="result-section">
        <h3 className="section-title">
          Model Explanation Flags
          <span className="section-subtitle">
            Aggregate statistics — not per-artifact detections
          </span>
        </h3>
        <FlagList flags={result.explanation_flags} />
      </div>

      {/* Transaction Protection Demo */}
      <TransactionCard result={result} />

      {/* Feedback */}
      <div className="result-section feedback-section">
        <button
          className="feedback-toggle"
          onClick={() => setShowFeedback((v) => !v)}
          aria-expanded={showFeedback}
        >
          {showFeedback ? '▲' : '▼'} Submit Analyst Feedback
        </button>

        {showFeedback && (
          <div className="feedback-form">
            {feedbackState === 'done' ? (
              <div className="feedback-done">✓ Feedback recorded. Thank you.</div>
            ) : (
              <>
                <label className="feedback-label" htmlFor="feedback-notes">
                  Notes (optional)
                </label>
                <input
                  id="feedback-notes"
                  className="feedback-notes-input"
                  type="text"
                  placeholder="e.g. confirmed genuine by call-back verification"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  disabled={feedbackState === 'submitting'}
                  maxLength={300}
                />
                <div className="feedback-buttons">
                  <button
                    id="feedback-correct"
                    className="btn-feedback btn-correct"
                    onClick={() => handleFeedback(true)}
                    disabled={feedbackState === 'submitting'}
                  >
                    👍 Model was correct
                  </button>
                  <button
                    id="feedback-wrong"
                    className="btn-feedback btn-wrong"
                    onClick={() => handleFeedback(false)}
                    disabled={feedbackState === 'submitting'}
                  >
                    👎 Model was wrong
                  </button>
                </div>
                {feedbackState === 'error' && (
                  <p className="feedback-error">Error: {feedbackError}</p>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function MetaRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="meta-row">
      <span className="meta-label">{label}</span>
      <span className="meta-value">{children}</span>
    </div>
  );
}

function TransactionCard({ result }: { result: AnalyzeResult }) {
  const band = riskBand(result.risk_score);

  let statusText: string;
  let statusClass: string;
  let actionText: string;

  if (result.verdict === 'cloned') {
    statusText = '⚠ BLOCKED — Secondary Verification Required';
    statusClass = 'tx-blocked';
    actionText = 'Recommended: Callback · MFA · Supervisor approval';
  } else if (result.verdict === 'replayed') {
    statusText = '⚠ BLOCKED — Physical Replay Attack Detected';
    statusClass = 'tx-blocked';
    actionText = 'Recommended: Callback on different channel · MFA · Escalation';
  } else if (result.verdict === 'uncertain') {
    statusText = '◉ HOLD — Additional Verification Recommended';
    statusClass = 'tx-uncertain';
    actionText = 'Proceed with caution. Consider secondary verification.';
  } else {
    statusText = '✓ CLEARED — Voice Consistent with Genuine Speech';
    statusClass = 'tx-cleared';
    actionText = "Voice appears consistent with the model's genuine-speech classification.";
  }

  return (
    <div className={`tx-protection-card tx-card-${band}`}>
      <div className="tx-header">
        <span className="tx-label">🏦 Sensitive Action Protection</span>
        <span className="tx-prototype-tag">Prototype Workflow Only</span>
      </div>
      <div className="tx-body">
        <div className="tx-row">
          <span className="tx-key">Action</span>
          <span className="tx-val">High-value fund transfer</span>
        </div>
        {result.caller_id && (
          <div className="tx-row">
            <span className="tx-key">Caller</span>
            <span className="tx-val"><code>{result.caller_id}</code></span>
          </div>
        )}
        <div className="tx-row">
          <span className="tx-key">Voice Risk Score</span>
          <span className="tx-val">{result.risk_score.toFixed(1)} / 100</span>
        </div>
        {result.decision && (
          <div className="tx-row">
            <span className="tx-key">System Decision</span>
            <span className="tx-val"><DecisionChip decision={result.decision} /></span>
          </div>
        )}
        <div className={`tx-status ${statusClass}`}>{statusText}</div>
        <p className="tx-action-text">{actionText}</p>
      </div>
      <p className="tx-disclaimer">
        This is a prototype workflow UI. Not connected to any banking system.
      </p>
    </div>
  );
}

