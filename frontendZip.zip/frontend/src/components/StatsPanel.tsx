import React, { useEffect, useState, useCallback } from 'react';
import { getStats } from '../api/client';
import type { StatsResponse } from '../types/api';

export function StatsPanel() {
  const [stats, setStats] = useState<StatsResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await getStats();
      setStats(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load stats');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="stats-container">
      <div className="stats-header">
        <h2 className="stats-title">Dashboard Statistics</h2>
        <button className="btn-refresh" onClick={load} disabled={loading} aria-label="Refresh statistics">
          {loading ? '⟳' : '↻'} Refresh
        </button>
      </div>

      {error && <div className="error-banner">⚠ {error}</div>}

      {!stats && !error && !loading && (
        <div className="history-empty">No statistics yet.</div>
      )}

      {stats && (
        <>
          {/* KPI Cards */}
          <div className="kpi-grid">
            <KpiCard
              id="kpi-total"
              label="Total Scans"
              value={stats.total_scans.toLocaleString()}
              icon="📊"
              color="cyan"
            />
            <KpiCard
              id="kpi-avg-risk"
              label="Avg Risk Score"
              value={stats.avg_risk_score.toFixed(1)}
              icon="🎯"
              color={stats.avg_risk_score > 64 ? 'red' : stats.avg_risk_score > 35 ? 'amber' : 'cyan'}
            />
            <KpiCard
              id="kpi-latency"
              label="Avg Latency"
              value={stats.avg_latency_ms < 1000
                ? `${stats.avg_latency_ms.toFixed(0)} ms`
                : `${(stats.avg_latency_ms / 1000).toFixed(2)} s`}
              icon="⚡"
              color="purple"
            />
            {stats.feedback_accuracy != null && (
              <KpiCard
                id="kpi-accuracy"
                label="Feedback Accuracy"
                value={`${stats.feedback_accuracy.toFixed(1)}%`}
                icon="✓"
                color="green"
              />
            )}
          </div>

          {/* Verdict Breakdown */}
          {Object.keys(stats.verdict_breakdown).length > 0 && (
            <div className="verdict-breakdown">
              <h3 className="breakdown-title">Verdict Breakdown</h3>
              <VerdictDonut breakdown={stats.verdict_breakdown} total={stats.total_scans} />
            </div>
          )}
        </>
      )}
    </div>
  );
}

function KpiCard({
  id, label, value, icon, color,
}: {
  id: string;
  label: string;
  value: string;
  icon: string;
  color: 'cyan' | 'amber' | 'red' | 'purple' | 'green';
}) {
  return (
    <div id={id} className={`kpi-card kpi-${color}`}>
      <div className="kpi-icon">{icon}</div>
      <div className="kpi-body">
        <div className="kpi-value">{value}</div>
        <div className="kpi-label">{label}</div>
      </div>
    </div>
  );
}

function VerdictDonut({
  breakdown,
  total,
}: {
  breakdown: Record<string, number>;
  total: number;
}) {
  const colors: Record<string, string> = {
    real: '#00d4ff',
    cloned: '#ff3d5a',
    uncertain: '#ffb347',
  };

  const verdicts = ['real', 'cloned', 'uncertain'] as const;
  const entries = verdicts
    .map((v) => ({ verdict: v, count: breakdown[v] ?? 0 }))
    .filter((e) => e.count > 0);

  if (total === 0) return null;

  // Build SVG donut segments
  const R = 60;
  const cx = 75;
  const cy = 75;
  const STROKE = 22;

  let cumulativePct = 0;
  const segments: { verdict: string; pct: number; dash: number; offset: number; color: string }[] = [];
  const circumference = 2 * Math.PI * R;

  for (const { verdict, count } of entries) {
    const pct = count / total;
    const dash = pct * circumference;
    const offset = cumulativePct * circumference;
    segments.push({ verdict, pct, dash, offset: -(offset), color: colors[verdict] ?? '#888' });
    cumulativePct += pct;
  }

  return (
    <div className="donut-wrapper">
      <svg viewBox="0 0 150 150" className="donut-svg" aria-label="Verdict breakdown donut chart">
        {segments.map(({ verdict, dash, offset, color }) => (
          <circle
            key={verdict}
            cx={cx}
            cy={cy}
            r={R}
            fill="none"
            stroke={color}
            strokeWidth={STROKE}
            strokeDasharray={`${dash} ${circumference - dash}`}
            strokeDashoffset={offset}
            strokeLinecap="butt"
            style={{
              transform: 'rotate(-90deg)',
              transformOrigin: `${cx}px ${cy}px`,
              filter: `drop-shadow(0 0 4px ${color}66)`,
            }}
          />
        ))}
        <text x={cx} y={cy - 4} textAnchor="middle" fill="#fff" fontSize="20" fontWeight="700" fontFamily="Inter, sans-serif">
          {total}
        </text>
        <text x={cx} y={cy + 14} textAnchor="middle" fill="rgba(255,255,255,0.4)" fontSize="9" fontFamily="Inter, sans-serif" letterSpacing="1">
          TOTAL
        </text>
      </svg>

      <div className="donut-legend">
        {entries.map(({ verdict, count }) => (
          <div key={verdict} className="legend-row">
            <span className="legend-dot" style={{ background: colors[verdict] ?? '#888' }} />
            <span className="legend-verdict">{verdict.charAt(0).toUpperCase() + verdict.slice(1)}</span>
            <span className="legend-count">{count}</span>
            <span className="legend-pct">{((count / total) * 100).toFixed(1)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}
