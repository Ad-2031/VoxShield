/**
 * API Types — mirrors backend schemas.py exactly (VoxShield v2.0.0).
 * Do NOT rename fields here without matching changes in the backend.
 */

export type Verdict = 'real' | 'cloned' | 'replayed' | 'uncertain';
export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type Decision = 'ALLOW' | 'REVIEW' | 'BLOCK';

export interface AnalyzeResult {
  scan_id: string;
  /** ISO-8601 UTC */
  timestamp: string;

  // ── core verdict ──────────────────────────────────────────────────
  /** 0 = safe, 100 = attack */
  risk_score: number;
  verdict: Verdict;
  /** 0–1 */
  confidence: number;
  risk_level: RiskLevel | null;
  decision: Decision | null;

  // ── synthetic / deepfake arm (XLSR-AASIST + AASIST3) ─────────────
  synthetic_score: number | null;      // 0–100
  xlsr_fake_prob: number | null;       // 0–100
  aasist3_available: boolean | null;
  aasist3_fake_prob: number | null;    // 0–100

  // ── DSP / replay arm (MFDSD + RawNet2) ───────────────────────────
  dsp_spoof_score: number | null;      // 0–100
  dsp_available: boolean | null;
  dsp_classification: string | null;   // 'AI_GENERATED' | 'REAL'
  dsp_feature_scores: Record<string, number> | null;
  replay_score: number | null;         // 0–100
  rawnet2_available: boolean | null;

  // ── speaker verification arm (ECAPA-TDNN) ────────────────────────
  speaker_verified: boolean | null;
  speaker_similarity: number | null;   // 0–100
  speaker_enrolled: boolean | null;

  // ── risk engine ───────────────────────────────────────────────────
  risk_contributions: Record<string, number> | null;

  // ── explainability ────────────────────────────────────────────────
  explanation_flags: string[];
  latency_ms: number;

  // ── metadata ──────────────────────────────────────────────────────
  audio_duration_sec: number | null;
  caller_id: string | null;
}

export interface HistoryResponse {
  total: number;
  items: AnalyzeResult[];
}

export interface StatsResponse {
  total_scans: number;
  avg_risk_score: number;
  avg_latency_ms: number;
  /** e.g. { real: 40, cloned: 12, uncertain: 3, replayed: 5 } */
  verdict_breakdown: Record<string, number>;
  risk_level_breakdown: Record<string, number>;
  /** % of feedback marked correct; null if no feedback submitted yet */
  feedback_accuracy: number | null;
}

export interface FeedbackRequest {
  scan_id: string;
  was_correct: boolean;
  notes?: string;
}

export interface FeedbackResponse {
  scan_id: string;
  recorded: boolean;
}

export interface EnrollResponse {
  caller_id: string;
  enrolled: boolean;
  message: string;
}

export interface VoiceprintEntry {
  caller_id: string;
  enrolled_at: string;
}

export interface VoiceprintsResponse {
  total: number;
  items: VoiceprintEntry[];
}
