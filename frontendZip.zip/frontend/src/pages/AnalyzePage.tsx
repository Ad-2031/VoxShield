import React, { useState, useCallback } from 'react';
import { analyzeAudio, ApiError } from '../api/client';
import type { AnalyzeResult } from '../types/api';
import { AudioUploader } from '../components/AudioUploader';
import { ResultCard } from '../components/ResultCard';

type State = 'idle' | 'analyzing' | 'done' | 'error';

export function AnalyzePage() {
  const [state, setState] = useState<State>('idle');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [durationSec, setDurationSec] = useState<number | undefined>(undefined);
  const [callerId, setCallerId] = useState('');
  const [result, setResult] = useState<AnalyzeResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleFileSelected = useCallback((file: File, dur: number | undefined) => {
    setSelectedFile(file);
    setDurationSec(dur);
    setResult(null);
    setErrorMsg(null);
    setState('idle');
  }, []);

  const handleClear = useCallback(() => {
    setSelectedFile(null);
    setDurationSec(undefined);
    setResult(null);
    setErrorMsg(null);
    setState('idle');
  }, []);

  const handleAnalyze = useCallback(async () => {
    if (!selectedFile) return;
    setState('analyzing');
    setResult(null);
    setErrorMsg(null);

    try {
      const res = await analyzeAudio(selectedFile, callerId || undefined, durationSec);
      setResult(res);
      setState('done');
    } catch (err) {
      let msg = 'Analysis failed.';
      if (err instanceof ApiError) {
        if (err.status === 0 || err.message.includes('fetch')) {
          msg = `Cannot reach backend at the configured URL. Ensure the backend is running:\n\ncd backend && uvicorn main:app --reload\n\nError: ${err.message}`;
        } else if (err.status === 400) {
          msg = `Bad request: ${err.message}`;
        } else if (err.status === 502) {
          msg = `Model inference failed: ${err.message}`;
        } else {
          msg = `Server error (${err.status}): ${err.message}`;
        }
      } else if (err instanceof TypeError && String(err).includes('fetch')) {
        msg = `Cannot reach backend. Ensure backend is running at http://127.0.0.1:8000\n\ncd backend && uvicorn main:app --reload`;
      } else if (err instanceof Error) {
        msg = err.message;
      }
      setErrorMsg(msg);
      setState('error');
    }
  }, [selectedFile, callerId, durationSec]);

  const handleReset = () => {
    setSelectedFile(null);
    setDurationSec(undefined);
    setResult(null);
    setErrorMsg(null);
    setState('idle');
    setCallerId('');
  };

  return (
    <div className="page-container">
      {/* Upload panel */}
      <div className="analyze-panel">
        <div className="analyze-panel-header">
          <h1 className="analyze-title">Voice Analysis</h1>
          <p className="analyze-subtitle">
            Upload an audio file to run AI-powered voice clone detection.
          </p>
        </div>

        <div className="analyze-form">
          {/* Audio upload */}
          <div className="form-field">
            <label className="field-label">Audio File</label>
            <AudioUploader
              onFileSelected={handleFileSelected}
              onClear={handleClear}
              disabled={state === 'analyzing'}
            />
          </div>

          {/* Caller ID */}
          <div className="form-field">
            <label className="field-label" htmlFor="caller-id-input">
              Caller ID <span className="field-optional">(optional)</span>
            </label>
            <input
              id="caller-id-input"
              className="text-input"
              type="text"
              placeholder="e.g. CUST-00142 / Agent Smith / +91 98765 43210"
              value={callerId}
              onChange={(e) => setCallerId(e.target.value)}
              disabled={state === 'analyzing'}
              maxLength={128}
            />
          </div>

          {/* Action buttons */}
          <div className="analyze-actions">
            <button
              id="analyze-button"
              className={`btn-analyze ${state === 'analyzing' ? 'btn-analyzing' : ''}`}
              onClick={handleAnalyze}
              disabled={!selectedFile || state === 'analyzing'}
              aria-live="polite"
            >
              {state === 'analyzing' ? (
                <>
                  <span className="spinner" aria-hidden="true" />
                  Analyzing Voice…
                </>
              ) : (
                <>
                  <span aria-hidden="true">▶</span> Analyze Voice
                </>
              )}
            </button>

            {(state === 'done' || state === 'error') && (
              <button className="btn-reset" onClick={handleReset} aria-label="Start a new analysis">
                ↺ New Analysis
              </button>
            )}
          </div>

          {/* Analyzing indicator */}
          {state === 'analyzing' && (
            <div className="analyzing-state" role="status" aria-live="polite">
              <div className="analyzing-wave">
                {[0, 1, 2, 3, 4].map((i) => (
                  <span key={i} className="wave-bar" style={{ animationDelay: `${i * 0.12}s` }} />
                ))}
              </div>
              <p>Running AI inference on submitted audio…</p>
              <p className="analyzing-sub">Model: wav2vec2-XLS-R 300M + AASIST graph attention</p>
            </div>
          )}

          {/* Error state */}
          {state === 'error' && errorMsg && (
            <div className="error-state" role="alert">
              <div className="error-icon">⚠</div>
              <pre className="error-message">{errorMsg}</pre>
            </div>
          )}
        </div>
      </div>

      {/* Result */}
      {state === 'done' && result && (
        <div className="result-wrapper">
          <ResultCard result={result} />
        </div>
      )}
    </div>
  );
}
