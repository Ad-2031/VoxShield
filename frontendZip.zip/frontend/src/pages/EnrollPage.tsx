import React, { useEffect, useState } from 'react';
import {
  enrollSpeaker,
  getVoiceprints,
  deleteVoiceprint,
  ApiError,
} from '../api/client';
import type { VoiceprintEntry } from '../types/api';

type EnrollState = 'idle' | 'uploading' | 'done' | 'error';

export function EnrollPage() {
  const [file, setFile] = useState<File | null>(null);
  const [callerId, setCallerId] = useState('');
  const [enrollState, setEnrollState] = useState<EnrollState>('idle');
  const [message, setMessage] = useState('');
  const [voiceprints, setVoiceprints] = useState<VoiceprintEntry[]>([]);
  const [loadingList, setLoadingList] = useState(false);

  async function loadVoiceprints() {
    setLoadingList(true);
    try {
      const data = await getVoiceprints();
      setVoiceprints(data.items);
    } catch {
      // silently ignore — list is optional UI enhancement
    } finally {
      setLoadingList(false);
    }
  }

  useEffect(() => {
    loadVoiceprints();
  }, []);

  async function handleEnroll(e: React.FormEvent) {
    e.preventDefault();
    if (!file || !callerId.trim()) return;
    setEnrollState('uploading');
    setMessage('');
    try {
      const resp = await enrollSpeaker(file, callerId.trim());
      setMessage(resp.message);
      setEnrollState('done');
      setFile(null);
      setCallerId('');
      loadVoiceprints();
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : 'Enrolment failed';
      setMessage(msg);
      setEnrollState('error');
    }
  }

  async function handleDelete(cid: string) {
    if (!confirm(`Delete voiceprint for "${cid}"?`)) return;
    try {
      await deleteVoiceprint(cid);
      setVoiceprints((prev) => prev.filter((v) => v.caller_id !== cid));
    } catch (err) {
      alert(err instanceof ApiError ? err.message : 'Delete failed');
    }
  }

  return (
    <div className="enroll-page page-fade-in">
      <div className="page-header">
        <h1 className="page-title">Speaker Enrolment</h1>
        <p className="page-subtitle">
          Register a voiceprint (ECAPA-TDNN embedding) for a caller ID.
          Once enrolled, every analysis call for that ID automatically includes
          speaker-verification scoring.
        </p>
      </div>

      <div className="enroll-layout">
        {/* Enrol form */}
        <div className="enroll-card">
          <h2 className="enroll-card-title">
            <span>🎤</span> Enrol a Voiceprint
          </h2>
          <form onSubmit={handleEnroll} className="enroll-form">
            <label className="enroll-label" htmlFor="enroll-caller-id">
              Caller / Speaker ID <span className="req">*</span>
            </label>
            <input
              id="enroll-caller-id"
              className="enroll-input"
              type="text"
              placeholder="e.g. user_001 or +91-9876543210"
              value={callerId}
              onChange={(e) => setCallerId(e.target.value)}
              required
              maxLength={100}
            />

            <label className="enroll-label" htmlFor="enroll-audio">
              Reference Audio (WAV/MP3/FLAC) <span className="req">*</span>
            </label>
            <p className="enroll-hint">
              Upload at least 5–10 seconds of clean speech by the target speaker.
              Background noise degrades verification accuracy.
            </p>
            <div className="enroll-file-wrapper">
              <label className="enroll-file-label" htmlFor="enroll-audio">
                {file ? `📎 ${file.name}` : '+ Choose audio file…'}
              </label>
              <input
                id="enroll-audio"
                className="enroll-file-input"
                type="file"
                accept="audio/*"
                onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                required
              />
            </div>

            <button
              type="submit"
              id="enroll-submit"
              className="btn-primary enroll-submit"
              disabled={enrollState === 'uploading' || !file || !callerId.trim()}
            >
              {enrollState === 'uploading' ? (
                <>⟳ Enrolling…</>
              ) : (
                <>🔑 Enrol Speaker</>
              )}
            </button>

            {message && (
              <div
                className={`enroll-message ${
                  enrollState === 'done' ? 'enroll-success' : 'enroll-error'
                }`}
              >
                {enrollState === 'done' ? '✓ ' : '✗ '}
                {message}
              </div>
            )}
          </form>
        </div>

        {/* Enrolled list */}
        <div className="enroll-card">
          <h2 className="enroll-card-title">
            <span>📋</span> Enrolled Voiceprints
            {!loadingList && (
              <span className="enroll-count">{voiceprints.length}</span>
            )}
          </h2>
          {loadingList ? (
            <p className="enroll-loading">Loading…</p>
          ) : voiceprints.length === 0 ? (
            <p className="enroll-empty">No voiceprints enrolled yet.</p>
          ) : (
            <div className="voiceprint-list">
              {voiceprints.map((vp) => (
                <div key={vp.caller_id} className="voiceprint-row">
                  <div className="vp-info">
                    <span className="vp-id">{vp.caller_id}</span>
                    <span className="vp-date">
                      Enrolled {new Date(vp.enrolled_at).toLocaleDateString()}
                    </span>
                  </div>
                  <button
                    className="vp-delete-btn"
                    onClick={() => handleDelete(vp.caller_id)}
                    title="Delete voiceprint"
                  >
                    🗑
                  </button>
                </div>
              ))}
            </div>
          )}
          <button
            className="btn-secondary enroll-refresh"
            onClick={loadVoiceprints}
            disabled={loadingList}
          >
            ↻ Refresh
          </button>
        </div>
      </div>

      {/* Info note */}
      <div className="enroll-info-box">
        <strong>How it works:</strong> The ECAPA-TDNN model extracts a 192-dimensional
        speaker embedding from the reference audio. During analysis, the embedding of
        the incoming call is compared against this reference using cosine similarity.
        A similarity below 75% contributes to the Identity Risk component of the
        composite risk score.
      </div>
    </div>
  );
}
