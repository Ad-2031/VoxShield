import React from 'react';
import { StatsPanel } from '../components/StatsPanel';

export function StatsPage() {
  return (
    <div className="page-container">
      <div className="page-header">
        <h1 className="page-title">Dashboard Statistics</h1>
        <p className="page-subtitle">
          Aggregate metrics across all analyses performed by the detection backend.
        </p>
      </div>
      <StatsPanel />
    </div>
  );
}
