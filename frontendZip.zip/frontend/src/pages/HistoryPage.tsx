import React from 'react';
import { HistoryTable } from '../components/HistoryTable';

export function HistoryPage() {
  return (
    <div className="page-container">
      <div className="page-header">
        <h1 className="page-title">Analysis History</h1>
        <p className="page-subtitle">
          All past voice analyses retrieved from the detection backend. Ordered most-recent first.
        </p>
      </div>
      <HistoryTable />
    </div>
  );
}
