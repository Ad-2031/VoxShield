/**
 * API Client — VoxShield v2.0.0
 *
 * All fetch calls centralised here.
 * Base URL: http://127.0.0.1:8000 (override via VITE_API_BASE_URL).
 *
 * /analyze uses multipart/form-data.
 * Do NOT set Content-Type manually — the browser must set it with the boundary.
 */

import type {
  AnalyzeResult,
  EnrollResponse,
  FeedbackRequest,
  FeedbackResponse,
  HistoryResponse,
  StatsResponse,
  VoiceprintsResponse,
} from '../types/api';

export const API_BASE: string =
  import.meta.env.VITE_API_BASE_URL ?? 'http://127.0.0.1:8000';

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

async function handleResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let detail = `HTTP ${res.status}`;
    try {
      const body = await res.json();
      detail = body?.detail ?? JSON.stringify(body);
    } catch {
      detail = await res.text().catch(() => detail);
    }
    throw new ApiError(res.status, detail);
  }
  return res.json() as Promise<T>;
}

// ── analyze ────────────────────────────────────────────────────────────────

/**
 * POST /api/v1/analyze
 * Sends audio as multipart/form-data.
 */
export async function analyzeAudio(
  file: File,
  callerId?: string,
  durationSec?: number,
): Promise<AnalyzeResult> {
  const form = new FormData();
  form.append('audio', file);
  if (callerId?.trim()) form.append('caller_id', callerId.trim());
  if (durationSec != null && isFinite(durationSec))
    form.append('audio_duration_sec', String(durationSec));

  const res = await fetch(`${API_BASE}/api/v1/analyze`, {
    method: 'POST',
    body: form,
  });
  return handleResponse<AnalyzeResult>(res);
}

// ── history / stats ────────────────────────────────────────────────────────

export async function getHistory(
  limit = 20,
  offset = 0,
): Promise<HistoryResponse> {
  const res = await fetch(
    `${API_BASE}/api/v1/history?limit=${limit}&offset=${offset}`,
  );
  return handleResponse<HistoryResponse>(res);
}

export async function getStats(): Promise<StatsResponse> {
  const res = await fetch(`${API_BASE}/api/v1/stats`);
  return handleResponse<StatsResponse>(res);
}

// ── feedback ───────────────────────────────────────────────────────────────

export async function submitFeedback(
  payload: FeedbackRequest,
): Promise<FeedbackResponse> {
  const res = await fetch(`${API_BASE}/api/v1/feedback`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return handleResponse<FeedbackResponse>(res);
}

// ── enrolment ──────────────────────────────────────────────────────────────

/**
 * POST /api/v1/enroll
 * Upload a WAV file to register a speaker voiceprint for the given callerId.
 */
export async function enrollSpeaker(
  file: File,
  callerId: string,
): Promise<EnrollResponse> {
  const form = new FormData();
  form.append('audio', file);
  form.append('caller_id', callerId.trim());

  const res = await fetch(`${API_BASE}/api/v1/enroll`, {
    method: 'POST',
    body: form,
  });
  return handleResponse<EnrollResponse>(res);
}

export async function getVoiceprints(): Promise<VoiceprintsResponse> {
  const res = await fetch(`${API_BASE}/api/v1/voiceprints`);
  return handleResponse<VoiceprintsResponse>(res);
}

export async function deleteVoiceprint(callerId: string): Promise<void> {
  const res = await fetch(
    `${API_BASE}/api/v1/voiceprints/${encodeURIComponent(callerId)}`,
    { method: 'DELETE' },
  );
  await handleResponse<unknown>(res);
}

// ── health ─────────────────────────────────────────────────────────────────

export async function pingBackend(): Promise<boolean> {
  try {
    const res = await fetch(`${API_BASE}/`, { signal: AbortSignal.timeout(3000) });
    return res.ok;
  } catch {
    return false;
  }
}
