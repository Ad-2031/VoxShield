import React, { useEffect, useState, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { AnalyzePage } from './pages/AnalyzePage';
import { HistoryPage } from './pages/HistoryPage';
import { StatsPage } from './pages/StatsPage';
import { EnrollPage } from './pages/EnrollPage';
import { pingBackend } from './api/client';

type Tab = 'analyze' | 'history' | 'stats' | 'enroll';

export default function App() {
  const [tab, setTab] = useState<Tab>('analyze');
  const [online, setOnline] = useState<boolean | null>(null);

  const checkBackend = useCallback(async () => {
    const ok = await pingBackend();
    setOnline(ok);
  }, []);

  useEffect(() => {
    checkBackend();
    // Re-check every 30 seconds
    const id = setInterval(checkBackend, 30_000);
    return () => clearInterval(id);
  }, [checkBackend]);

  return (
    <div className="app">
      <Navbar online={online} />

      {/* Tab navigation */}
      <nav className="tab-nav" role="navigation" aria-label="Main navigation">
        <div className="tab-nav-inner">
          {(
            [
              { id: 'analyze', label: '🎙 Analyze', ariaLabel: 'Go to voice analysis' },
              { id: 'history', label: '📋 History', ariaLabel: 'Go to analysis history' },
              { id: 'stats', label: '📊 Statistics', ariaLabel: 'Go to dashboard statistics' },
              { id: 'enroll', label: '🎤 Enrol', ariaLabel: 'Go to speaker enrolment' },
            ] as { id: Tab; label: string; ariaLabel: string }[]
          ).map(({ id, label, ariaLabel }) => (
            <button
              key={id}
              id={`tab-${id}`}
              className={`tab-btn ${tab === id ? 'tab-active' : ''}`}
              onClick={() => setTab(id)}
              aria-label={ariaLabel}
              aria-selected={tab === id}
              role="tab"
            >
              {label}
            </button>
          ))}
        </div>
      </nav>

      {/* Page content */}
      <main className="main-content" role="main">
        {tab === 'analyze' && <AnalyzePage />}
        {tab === 'history' && <HistoryPage />}
        {tab === 'stats' && <StatsPage />}
        {tab === 'enroll' && <EnrollPage />}
      </main>

      {/* Footer */}
      <footer className="footer" role="contentinfo">
        <div className="footer-inner">
          <div className="privacy-notice">
            <span className="privacy-icon">🔒</span>
            <span>
              <strong>Privacy Notice:</strong> This prototype processes submitted audio through the
              configured detection backend. Production deployment should use edge inference, minimal
              data retention, and appropriate privacy controls.
            </span>
          </div>
          <div className="footer-meta">
            <span>VoxShield · SIH 2026 · PS 26104</span>
            <span>AI-Powered Voice Integrity Verification</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
