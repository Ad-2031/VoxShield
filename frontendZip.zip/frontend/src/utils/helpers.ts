/** Shared helper utilities */

import type { Verdict } from '../types/api';

/** Map a risk_score [0–100] to a UI band */
export function riskBand(score: number): 'low' | 'uncertain' | 'high' {
  if (score <= 35) return 'low';
  if (score <= 64) return 'uncertain';
  return 'high';
}

/** Verdict → CSS class suffix */
export function verdictClass(verdict: Verdict): string {
  return verdict; // 'real' | 'cloned' | 'replayed' | 'uncertain'
}

/** Format ISO timestamp to a human-readable local string */
export function fmtTime(iso: string): string {
  try {
    return new Date(iso).toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  } catch {
    return iso;
  }
}

/** Format a duration in seconds nicely */
export function fmtDuration(sec: number | null): string {
  if (sec == null) return '—';
  if (sec < 60) return `${sec.toFixed(1)} s`;
  const m = Math.floor(sec / 60);
  const s = (sec % 60).toFixed(0).padStart(2, '0');
  return `${m}m ${s}s`;
}

/** Format latency ms */
export function fmtLatency(ms: number): string {
  if (ms < 1000) return `${ms.toFixed(0)} ms`;
  return `${(ms / 1000).toFixed(2)} s`;
}

/** Format confidence as a percentage string */
export function fmtConfidence(c: number): string {
  return `${(c * 100).toFixed(1)}%`;
}

/** Friendly label for a verdict */
export function verdictLabel(v: Verdict): string {
  const labels: Record<string, string> = {
    real: 'Genuine',
    cloned: 'AI-Cloned',
    replayed: 'Replay Attack',
    uncertain: 'Uncertain',
  };
  return labels[v] ?? v;
}

/** Risk recommendation text */
export function riskRecommendation(verdict: Verdict): string {
  if (verdict === 'cloned')
    return 'AI-synthesised voice detected. Block action and trigger secondary verification (callback, MFA).';
  if (verdict === 'replayed')
    return 'Physical replay attack detected. Block action and verify caller via an independent channel.';
  if (verdict === 'uncertain')
    return 'Suspicious indicators found. Additional verification recommended before sensitive actions.';
  return 'No synthetic speech indicators detected. Voice appears consistent with genuine speech.';
}

/** Format an explanation_flag key into a human display (preserving original) */
export function fmtFlag(flag: string): string {
  return flag.replace(/_/g, ' ');
}

/** File size display */
export function fmtBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}
